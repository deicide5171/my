# HMNS MAP 2.5D API

1. git clone ssh://{계정}@git.hyundai-mnsoft.com:29418/COM.COM.mEng.MB/map25dapi

2. Node Library 설치
    1. Node.js 설치된 경우 : ./map25dapi/npm i
    2. Node.js 설치 안된 경우 : 공유폴더에서 node_modules.zip 다운로드 받아서 ./map25dapi에 압축풀기 (공유폴더 경로 : \\mnsoft-bs2\웹지도엔진개발_올포랜드\03.2019_prj_11~04\99.기타참고자료\map25dapi_node_modules)

3. Script 명령어 (npm run {명령어})
    1. build : JS 문법 검사 + JSDoc 생성 + Example 생성 + JS Bundle 생성
    2. test : Example 테스트용 JS Bundle 생성
    3. rollup : 타입별 JS Bundle 생성
    4. example : Example 생성 및 로컬서버 open (http://localhost:3000/build/examples)
    5. exam : Example 생성
    6. jsdoc : JSDoc 생성
    7. lint : JS 문법 검사

4. 프로젝트 폴더 및 파일 구조
    1. /build : "npm run build" 명령어 결과 파일이 생성되는 폴더
    2. /config : Example, JSDoc 생성에 대한 설정 파일이 저장되어 있는 폴더
        1. /config/examples/example.html : Example 페이지 기본 Template HTML 파일
    3. /examples : Example HTML, JS 파일 폴더. Example 수정 및 추가시 해당 폴더에서 작업
        1. /examples/resources : glyphs(폰트), sprite(주기이미지), playmap 로고이미지 등이 저장된 폴더
        2. /examples/index.html : Example 메인 페이지 Template HTML 파일
    4. /src : 2.5D Map API JS 폴더
        1. /src/index.js : API에서 사용하는 클래스 단위(JS) 목록. 여기에 포함된 JS들만 Bundle 파일에 포함된다.
    5. / : JSDoc 설정, rollup 설정, node 설정 파일 존재하는 루트  폴더
        1. /jsdoc.json : JSDoc 설정 파일
        2. /rollup.config.js : rollup 설정 파일
        3. /rollup.config.test.js : Debugging 가능한 bundle 파일 하나만 빠르게 생성하기 위한 설정 파일
        4. /package.json : 설치된 Node Library 확인 및 Script 명령어 확인이 가능한 설정 파일

- 관련 링크

[API Reference](https://docs.mapbox.com/mapbox-gl-js/api/)

[Style Specification](https://docs.mapbox.com/mapbox-gl-js/style-spec/)